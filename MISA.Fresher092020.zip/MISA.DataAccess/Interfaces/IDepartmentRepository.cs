﻿using MISA.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.DataAccess.Interfaces
{
    public interface IDepartmentRepository:IBaseRepository<Department>
    {
        
    }
}
