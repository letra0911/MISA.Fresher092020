﻿$(document).ready(function () {
        employeeJS = new EmployeeJS("Mạnh");
})

/**
 * class quản lý các function cho trang Customer
 * Author: NVMANH (25/09/2020 )
 * */
class EmployeeJS extends BaseJS {
    constructor(name) {
            super();
    }
}

