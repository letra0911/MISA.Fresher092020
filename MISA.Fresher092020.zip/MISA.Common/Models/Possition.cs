﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.Common.Models
{
    public class Possition
    {
        public Guid PossitionId { get; set; }
        public string PossitionName { get; set; }
    }
}
